import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import client from '../api/client'

interface PlayerStat {
  id: string
  matchId: string
  match: {
    scheduledAt: string
    homeTeam: { name: string }
    awayTeam: { name: string }
  }
  goals: number
  assists: number
  yellowCards: number
  redCards: number
  minutesPlayed: number
}

export default function PlayerStatsPage() {
  const { userId } = useParams<{ userId: string }>()
  const [stats, setStats] = useState<PlayerStat[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    client.get(`/players-stats/user/${userId}`)
      .then(res => setStats(res.data))
      .catch(() => setError('Error al cargar estadísticas'))
      .finally(() => setLoading(false))
  }, [userId])

  const totals = stats.reduce(
    (acc, s) => ({
      goals: acc.goals + s.goals,
      assists: acc.assists + s.assists,
      yellowCards: acc.yellowCards + s.yellowCards,
      redCards: acc.redCards + s.redCards,
      minutesPlayed: acc.minutesPlayed + s.minutesPlayed,
    }),
    { goals: 0, assists: 0, yellowCards: 0, redCards: 0, minutesPlayed: 0 }
  )

  if (loading) return <p>Cargando...</p>
  if (error) return <p>{error}</p>

  return (
    <div>
      <h1>Estadísticas del jugador</h1>

      <h2>Resumen</h2>
      <ul>
        <li>Goles: {totals.goals}</li>
        <li>Asistencias: {totals.assists}</li>
        <li>Tarjetas amarillas: {totals.yellowCards}</li>
        <li>Tarjetas rojas: {totals.redCards}</li>
        <li>Minutos jugados: {totals.minutesPlayed}</li>
      </ul>

      <h2>Por partido</h2>
      {stats.length === 0 ? (
        <p>Sin estadísticas registradas.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Partido</th>
              <th>Fecha</th>
              <th>Goles</th>
              <th>Asist</th>
              <th>TA</th>
              <th>TR</th>
              <th>Min</th>
            </tr>
          </thead>
          <tbody>
            {stats.map(s => (
              <tr key={s.id}>
                <td>{s.match.homeTeam.name} vs {s.match.awayTeam.name}</td>
                <td>{new Date(s.match.scheduledAt).toLocaleDateString('es-MX')}</td>
                <td>{s.goals}</td>
                <td>{s.assists}</td>
                <td>{s.yellowCards}</td>
                <td>{s.redCards}</td>
                <td>{s.minutesPlayed}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}