import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import client from '../api/client'

interface Tournament {
  id: string
  name: string
  sport: string
  status: string
  startDate: string
  endDate: string
}

export default function TournamentsPage() {
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  useEffect(() => {
    client.get('/tournaments')
      .then(res => setTournaments(res.data))
      .catch(() => setError('Error al cargar torneos'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <p>Cargando...</p>
  if (error) return <p>{error}</p>

  return (
    <div>
      <h1>Torneos</h1>
      {tournaments.length === 0 && <p>No hay torneos registrados.</p>}
      <ul>
        {tournaments.map(t => (
          <li key={t.id} onClick={() => navigate(`/tournaments/${t.id}`)}>
            <strong>{t.name}</strong> — {t.sport} — {t.status}
          </li>
        ))}
      </ul>
    </div>
  )
}