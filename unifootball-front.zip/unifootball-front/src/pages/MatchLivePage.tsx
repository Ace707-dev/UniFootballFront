import { useEffect, useState, useRef } from 'react'
import { useParams } from 'react-router-dom'
import client from '../api/client'

interface MatchEvent {
  _id: string
  type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'foul'
  minute: number
  playerName: string
  teamName: string
}

interface MatchResult {
  homeScore: number
  awayScore: number
  status: string
}

export default function MatchLivePage() {
  const { matchId } = useParams<{ matchId: string }>()
  const [events, setEvents] = useState<MatchEvent[]>([])
  const [result, setResult] = useState<MatchResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const fetchData = () => {
    client.get(`/matches/live/${matchId}`)
      .then(res => {
        setEvents(res.data.events ?? [])
        setResult(res.data.result ?? null)
      })
      .catch(() => setError('Error al cargar el partido'))
  }

  useEffect(() => {
    fetchData()
    intervalRef.current = setInterval(fetchData, 5000)
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [matchId])

  const eventIcon = (type: MatchEvent['type']) => {
    switch (type) {
      case 'goal': return '⚽'
      case 'yellow_card': return '🟨'
      case 'red_card': return '🟥'
      case 'substitution': return '🔄'
      case 'foul': return '⚠️'
    }
  }

  if (error) return <p>{error}</p>

  return (
    <div>
      <h1>Partido en vivo</h1>

      {result && (
        <div>
          <h2>
            {result.homeScore} - {result.awayScore}
          </h2>
          <p>Estado: {result.status}</p>
        </div>
      )}

      <h2>Eventos</h2>
      {events.length === 0 ? (
        <p>Sin eventos aún...</p>
      ) : (
        <ul>
          {events
            .sort((a, b) => a.minute - b.minute)
            .map(e => (
              <li key={e._id}>
                {eventIcon(e.type)} {e.minute}' — {e.playerName} ({e.teamName})
              </li>
            ))}
        </ul>
      )}
    </div>
  )
}