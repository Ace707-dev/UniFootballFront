import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import client from '../api/client'
import { useNavigate } from 'react-router-dom'

const navigate = useNavigate()

interface Standing {
  id: string
  teamId: string
  team: { name: string }
  played: number
  won: number
  drawn: number
  lost: number
  goalsFor: number
  goalsAgainst: number
  points: number
}

interface Match {
  id: string
  scheduledAt: string
  venue: string | null
  homeTeam: { name: string }
  awayTeam: { name: string }
  result?: {
    homeScore: number
    awayScore: number
    status: string
  }
}

export default function TournamentDetailPage() {
  const { id } = useParams<{ id: string }>()
  const [standings, setStandings] = useState<Standing[]>([])
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    Promise.all([
      client.get(`/standings?tournament_id=${id}`),
      client.get(`/matches?tournament_id=${id}`),
    ])
      .then(([standingsRes, matchesRes]) => {
        setStandings(standingsRes.data)
        setMatches(matchesRes.data)
      })
      .catch(() => setError('Error al cargar el torneo'))
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <p>Cargando...</p>
  if (error) return <p>{error}</p>

  return (
    <div>
      <h1>Torneo</h1>

      <h2>Tabla de posiciones</h2>
      {standings.length === 0 ? (
        <p>Sin datos de posiciones aún.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Equipo</th>
              <th>PJ</th>
              <th>G</th>
              <th>E</th>
              <th>P</th>
              <th>GF</th>
              <th>GC</th>
              <th>Pts</th>
            </tr>
          </thead>
          <tbody>
            {standings
              .sort((a, b) => b.points - a.points)
              .map(s => (
                <tr key={s.id}>
                  <td>{s.team.name}</td>
                  <td>{s.played}</td>
                  <td>{s.won}</td>
                  <td>{s.drawn}</td>
                  <td>{s.lost}</td>
                  <td>{s.goalsFor}</td>
                  <td>{s.goalsAgainst}</td>
                  <td>{s.points}</td>
                </tr>
              ))}
          </tbody>
        </table>
      )}

      <h2>Fixture</h2>
      {matches.length === 0 ? (
        <p>Sin partidos programados.</p>
      ) : (
        <ul>
          {matches.map(m => (
            <li
                key={m.id}
                onClick={() => navigate(`/matches/${m.id}/live`)}
                style={{ cursor: 'pointer' }}
                >
              <strong>{m.homeTeam.name}</strong>
              {m.result && m.result.status === 'played'
                ? ` ${m.result.homeScore} - ${m.result.awayScore} `
                : ' vs '}
              <strong>{m.awayTeam.name}</strong>
              {' — '}
              {new Date(m.scheduledAt).toLocaleDateString('es-MX')}
              {m.venue && ` — ${m.venue}`}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}