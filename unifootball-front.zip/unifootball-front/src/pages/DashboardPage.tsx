import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function DashboardPage() {
  const { logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div>
      <h1>Dashboard</h1>
      <button onClick={() => navigate('/tournaments')}>Ver torneos</button>
      <button onClick={handleLogout}>Cerrar sesión</button>
    </div>
  )
}